package Book_2.Chapter_5;

public class CountBothWays {

    public static void main(String[] args) {
        int a, b;
        for (a = 1, b = 10; a <= 10; a++, b--) {
            System.out.println(a + " " + b);
        }
    }
}
