package Book_2.Chapter_5;

public class CountToTen
{
    public static void main(String[] args)
    {
        int i;
        for (i = 1; i <= 10; i++) {
            System.out.println(i);
        }
        System.out.println("The final value of i is: " + i);
    }

}