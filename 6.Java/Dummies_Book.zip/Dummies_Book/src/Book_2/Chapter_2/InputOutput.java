package Book_2.Chapter_2;

public class InputOutput {

    public static void main(String[] args) {
        int i = 64;
        int j = 23;
        System.out.println(i);
        System.out.print(" and ");
        System.out.print(j);
    }
}
