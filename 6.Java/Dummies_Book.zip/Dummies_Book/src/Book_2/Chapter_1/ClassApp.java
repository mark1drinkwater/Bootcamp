package Book_2.Chapter_1;

public class ClassApp {
    public static void main (String args[]) {
        for (int i = 0; i < 5; i++) {
            System.out.println("Hi");
        }
    }
}
