package Book_1.Chapter_1;

public class HelloApp3
{
    public static void main (String[] args)
    {
        System.out.println(args[0] + " " + args[2]);
    }
}
