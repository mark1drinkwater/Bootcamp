package Book_3.Chapter_4;

public class Game {

    public void play() {
        System.out.println("Playing a game.");
    }
}

class Chess extends Game {
    public void play() {
        System.out.println("Playing chess.");
    }
}
