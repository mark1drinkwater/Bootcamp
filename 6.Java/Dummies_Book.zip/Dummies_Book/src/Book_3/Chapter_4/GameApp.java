package Book_3.Chapter_4;

public class GameApp {

    public static void main(String[] args) {
        Chess chess1 = new Chess();
        chess1.play();
    }
}
