package Book_3.Chapter_4;

public class ProductDataException extends Exception
{
    public ProductDataException(String message)
    {

        super(message);
    }
}