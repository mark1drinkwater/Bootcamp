package Book_3.Chapter_3;

public class Validation {

    // Prevents instantiation. Because they can't access the constructor.
    private Validation() {

    }
}
