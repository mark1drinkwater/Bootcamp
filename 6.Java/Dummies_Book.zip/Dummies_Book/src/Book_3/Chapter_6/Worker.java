package Book_3.Chapter_6;

public class Worker
{
    private String lastName;
    private String firstName;
    public Worker(String lastName, String firstName)
    {
        this.lastName = lastName;
        this.firstName = firstName;
    }

}
