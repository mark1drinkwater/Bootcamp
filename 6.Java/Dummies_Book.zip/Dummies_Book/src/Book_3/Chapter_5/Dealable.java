package Book_3.Chapter_5;

public interface Dealable {

    void deal(int cards);
}
