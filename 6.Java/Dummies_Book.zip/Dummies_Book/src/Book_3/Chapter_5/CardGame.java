package Book_3.Chapter_5;

public interface CardGame
{
    void shuffleCards();
}
