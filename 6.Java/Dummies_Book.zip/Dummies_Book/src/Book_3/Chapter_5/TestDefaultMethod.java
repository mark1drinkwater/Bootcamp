package Book_3.Chapter_5;

public class TestDefaultMethod {

    public static void main(String[] args) {
        Game g = new Game();
        g.play();
        g.quit();
    }
}
