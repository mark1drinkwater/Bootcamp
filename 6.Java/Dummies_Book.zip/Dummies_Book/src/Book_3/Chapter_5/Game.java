package Book_3.Chapter_5;

public class Game implements Playable {
    @Override
    public void play() {
        System.out.println("You're now playing the game.");
    }
}
