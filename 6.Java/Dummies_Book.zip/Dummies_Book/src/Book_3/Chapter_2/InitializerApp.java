package Book_3.Chapter_2;

public class InitializerApp {

    public static void main(String[] args) {
        Initializer si = new Initializer();
    }
}
