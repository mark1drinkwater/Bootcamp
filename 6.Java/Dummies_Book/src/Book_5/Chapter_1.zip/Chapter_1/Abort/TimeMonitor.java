package Book_5.Chapter_1.Abort;

interface  TimeMonitor
{
    int getTime();
    void abortCountDown();
}