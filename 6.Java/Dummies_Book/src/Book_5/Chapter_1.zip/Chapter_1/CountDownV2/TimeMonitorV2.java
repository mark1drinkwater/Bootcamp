package Book_5.Chapter_1.CountDownV2;

public interface TimeMonitorV2
{
    int getTime();
}
