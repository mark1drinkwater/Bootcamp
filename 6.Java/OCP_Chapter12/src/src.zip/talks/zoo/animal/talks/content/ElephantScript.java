package zoo.animal.talks.content;

public class ElephantScript {
}
