package zoo.animal.talks.media;

public class Announcement {

    public static void main(String[] args) {
        System.out.println("We will be having talks");
    }
}
