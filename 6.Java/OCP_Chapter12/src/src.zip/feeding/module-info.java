module zoo.animal.feeding {
  exports zoo.animal.feeding;
}
