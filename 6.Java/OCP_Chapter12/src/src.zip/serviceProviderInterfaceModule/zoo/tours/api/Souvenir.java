package zoo.tours.api;

public record Souvenir(String description) { }