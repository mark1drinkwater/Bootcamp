module zoo.staff {

    requires zoo.animal.feeding;
    requires zoo.animal.care;
    requires zoo.animal.talks;
}