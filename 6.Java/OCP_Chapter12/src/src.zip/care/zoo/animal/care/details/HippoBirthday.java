package care.zoo.animal.care.details;

import zoo.animal.feeding.*;

public class HippoBirthday {

    private Task task;
}