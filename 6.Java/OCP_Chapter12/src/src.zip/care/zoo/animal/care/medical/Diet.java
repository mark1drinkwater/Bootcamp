package zoo.animal.care.medical;

public class Diet {


}