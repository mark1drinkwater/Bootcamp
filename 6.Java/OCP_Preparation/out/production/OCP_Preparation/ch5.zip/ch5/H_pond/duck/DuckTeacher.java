package pond.duck;

public class DuckTeacher {
    public String name = "helpful";
    public void swim() {
       System.out.println(name + " teacher duck gives swimming lessons.");
    }
}
