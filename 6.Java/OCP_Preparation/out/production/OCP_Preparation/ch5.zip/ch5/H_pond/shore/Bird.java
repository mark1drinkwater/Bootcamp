package ch5.H_pond.shore;

public class Bird {
    protected String text = "floating";
    protected void floatInWater() {
        System.out.println(text);
    }
}
