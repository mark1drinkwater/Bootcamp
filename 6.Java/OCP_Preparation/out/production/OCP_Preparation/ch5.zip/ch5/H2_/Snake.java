package ch5.H2_;

public class Snake {
    public static String hiss = "hiss";
    public static void makeSnakeNoise() {
        System.out.println(hiss);
    }
}
