package ch5;

public class Q1_BoxingUnboxing {
    public static void main(String[] args) {
        int quack = 5;
        Integer quackquack = quack;
        int quackquackquack = quackquack;
    }
}
