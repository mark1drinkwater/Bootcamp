package ch13;

public class J_SynchronizingMethods {
}
