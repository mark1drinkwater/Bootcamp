package ch6.categorised;

public class A1_BigCat {
    protected double size;
}
