package ch6.categorised;

class Bird {}
class Bear {}
class Fish {}

//protected class ClownFish{} // DOES NOT COMPILE
//private class BlueTang {} // DOES NOT COMPILE