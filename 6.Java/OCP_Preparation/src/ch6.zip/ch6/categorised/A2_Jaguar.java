package ch6.categorised;

public class A2_Jaguar extends A1_BigCat {
    public A2_Jaguar() {
        size = 10.2;
    }
    public void printDetails() {
        System.out.print(size);
    }
}