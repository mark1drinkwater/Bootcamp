package ch6.categorised;

public class A4_FinalClasses {
}

class Mammal {}
final class Rhinoceros extends Mammal {}
//public class Clara extends Rhinoceros {} // Does Not Compile