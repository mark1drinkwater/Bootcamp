package ch6.categorised;

public class A3_Spider {
    public void printDetails() {
//        System.out.println(size); // DOES NOT COMPILE
    }
}