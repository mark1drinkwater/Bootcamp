package ch6.abstracts;

public abstract class Canine {
    public abstract String getSound();

    public void bark() {
        System.out.println(getSound());
    }
}

class Wolf extends Canine {

    @Override
    public String getSound() {
        return null;
    }
}

class Fox extends Canine {

    @Override
    public String getSound() {
        return null;
    }
}

class Coyote extends Canine {

    @Override
    public String getSound() {
        return null;
    }
}

class CanineTest {
    public static void main(String[] args) {
        Wolf wolf = new Wolf();
        Fox fox = new Fox();
        Coyote c = new Coyote();

//        Canine c2 = new Canine(); // Does Not Compile
    }
}

abstract class Bear { // DOES NOT COMPILE
    abstract public int howl(); // DOES NOT COMPILE
}