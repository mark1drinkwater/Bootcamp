package ch1;

public class A_Animal {
    String name;
    public String getName() {
        return name;
    }
    public void setName(String newName) {
        name = newName;
    }

    public int numberVisitors(int month) {
        return 10;
    }
}