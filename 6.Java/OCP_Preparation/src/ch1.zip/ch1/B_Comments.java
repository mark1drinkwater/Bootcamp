package ch1;

public class B_Comments {
    // single line comment

    /*
      Multi
      line
      comment
     */

    /**
     * Javadoc multiple-line comment
     * @author Jeanne and Scott
     */

}
