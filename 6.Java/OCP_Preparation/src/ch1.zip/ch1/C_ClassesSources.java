package ch1;

public class C_ClassesSources {
}

class Animal {
    String name;
}

