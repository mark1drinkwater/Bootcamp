package ch1.I_compilingRunningPackages.packageA;
//package packageA;

public class ClassA {
    public static void main(String[] args) {
        System.out.println("Hello I'm from Class A.");
    }
}
