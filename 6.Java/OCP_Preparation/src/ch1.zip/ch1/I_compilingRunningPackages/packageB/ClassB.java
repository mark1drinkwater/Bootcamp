package ch1.I_compilingRunningPackages.packageB;
//package packageB;

public class ClassB {
    public static void main(String[] args) {
        System.out.println("Hi I'm from Class b");
    }
}
