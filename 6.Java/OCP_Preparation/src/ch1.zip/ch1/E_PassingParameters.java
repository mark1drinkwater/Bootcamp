package ch1;

public class E_PassingParameters {
}

class Zoo {
    public static void main(String[] args) {
        System.out.println(args[0]);
        System.out.println(args[1]);

        // Change argument to "San Diego" Zoo
    }
}