package ch1; // package must be first non-comment
import java.util.*; // import must come after package
class Meerkat { // then comes the class
    double weight; // fields and methods can go in either order
    public double getWeight() {
        return weight; }
    double height; // another field - they don't need to be together
}


public class J_OrderingElements {
}
