import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import TodoApp from './todo/TodoApp'

function App() {
  return (
    <div className="App">
      <TodoApp></TodoApp>
    </div>
  );
}

export default App;
